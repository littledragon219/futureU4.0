import LandingPage from "../landing-page"

export default function Page() {
  return (
    <div>
      <LandingPage />
    </div>
  )
}
